
<h1>Recherche d'un oligo par <?= $critere ?></h1>

<form action="./?action=listeResultatBox&critere=<?= $critere ?>&page=1" method="POST">


    <?php
    switch ($critere) {
        case "code":
    ?>
            Saisir le code de la boite à rechercher<br />
            <input type="text" name="codeBox" placeholder="code..." value="" /><br />
    <?php
    }
    ?>
    <br />
    <input type="submit" value="Rechercher" />

</form>
