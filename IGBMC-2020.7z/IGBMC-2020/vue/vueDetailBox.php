
<h1>Box : <?= $uneBoite['code']; ?></h1>


<p id="principal">
    
<div class="container">
  <form action="action_page.php">
      
    <div class="row">
      <div class="col-25">
        <label for="lname">Code</label>
      </div>
      <div class="col-75">
      
            <p id="texteSequence"><?= $uneBoite['code'] ?></p>
      </div>
    </div>
      
      <h2>Contenu de la boite : <?= count($lesOligos)?> oligo(s)</h2>
        <table>
            <thead>
                <tr>
                    <th>name</th>
                </tr>
            </thead>
            <tbody>
<?php              
        for($i = 0; $i < count($lesOligos); $i++){
?>
            <tr>
<?php            
                $id = $lesOligos[$i]['id'];
                $nom = $lesOligos[$i]['name'];
?>
                <td><a href='./?action=detailOligo&id=<?= $id ?>'><?= $nom ?></a></td>
            </tr>
  
<?php
        }
?>
        </table>      
      
     </form>
</div>    
</p>