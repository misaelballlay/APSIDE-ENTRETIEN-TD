
<h1>Recherche d'un oligo par <?= $critere ?></h1>

<form action="./?action=listeResultatOligo&critere=<?= $critere ?>&page=1" method="POST">


    <?php
    switch ($critere) {
        case "nom":
    ?>
            Saisir le nom à rechercher<br />
            <input type="text" name="nomOligo" placeholder="nom..." value="" /><br />
    <?php
            break;
        
        case "sequence":
    ?>      
            Saisir la séquence à rechercher<br />
            <input type="text" name="sequence" placeholder="Séquence..." value="" /><br />            
    <?php
    }
    ?>
    <br />
    <input type="submit" value="Rechercher" />

</form>
