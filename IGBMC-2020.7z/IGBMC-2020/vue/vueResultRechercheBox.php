
<h1>Boites qui répondent au critère de recherche</h1>
    <div class="card">
    

<?php
    if(count($lesBoites) > 0){
        
        //Détermination de début et fin de parcour du curseur en fonction de la pagination
        $nbBoite = count($lesBoites);        
        $nbPages = intval($nbBoite / 10) + 1;

        $numPage = $_GET['page'];
        
        $debut = ($numPage - 1) * 10;
        $fin = $debut + 9;
        if($fin > $nbBoite){
            $fin = $nbBoite - 1;
        }
?>
        <table>
            <thead>
                <tr>
                    <th>Code</th>
                </tr>
            </thead>
            <tbody>
<?php                
        for($i = $debut; $i <= $fin; $i++){
            
            $id = $lesBoites[$i]['id'];            
            $code = $lesBoites[$i]['code'];
?>
            <tr>
            <td><a href='./?action=detailBox&id=<?= $id ?>'><?= $code ?></a></td>
            </tr>
  
<?php
        }
?>
        </table>
        Page(s)
<?php        
        //Affichage du nombre de page du curseur qui selon le critère
        switch($critere){
            case "code":
                for($i = 1; $i <= $nbPages; $i++){
                    echo "<a href='./?action=listeResultatBox&critere=".$critere."&codeBox=".$codeBox."&page=".$i."'>".$i.", </a>";
                } 
        }
               
    }
    else{
?>
        <p>
            Aucune occurence trouvée...
        </p>
<?php
}
?>