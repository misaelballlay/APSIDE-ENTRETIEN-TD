
<br />
<p id ="texteAdroite">
    BTS SIO - Lycée Camille Sée - Colmar
</p>
</div>



</body>


</html>