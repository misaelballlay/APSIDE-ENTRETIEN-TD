
<h1>Oligos qui répondent au critère de recherche</h1>
    <div class="card">
    

<?php
    if(count($lesOligos) > 0){
        
        //Détermination de début et fin de parcour du curseur en fonction de la pagination
        $nbOligo = count($lesOligos);        
        $nbPages = intval($nbOligo / 10) + 1;

        $numPage = $_GET['page'];
        
        $debut = ($numPage - 1) * 10;
        $fin = $debut + 9;
        if($fin > $nbOligo){
            $fin = $nbOligo - 1;
        }
?>
        <table>
            <thead>
                <tr>
                    <th>name</th>
                </tr>
            </thead>
            <tbody>
<?php                
        $sequence = $_POST['sequence'];

        for($i = $debut; $i <= $fin; $i++){
            
            $id = $lesOligos[$i]['id'];
            $nom = $lesOligos[$i]['name'];
?>
            <tr>
<?php
                if($critere == "sequence"){
                    echo "<td><a href='./?action=detailOligo&id=" . $id . "&seq=".$sequence."'>".$nom."</a></td>";                    
                }
                else{
                    echo "<td><a href='./?action=detailOligo&id=" . $id . "'>".$nom."</a></td>";
                }
?>                
            </tr>
  
<?php
        }
?>
        </table>
        Page(s)
<?php        
        //Affichage du nombre de page du curseur qui selon le critère
        switch($critere){
            case "nom":
                for($i = 1; $i <= $nbPages; $i++){
                    echo "<a href='./?action=listeResultatOligo&critere=".$critere."&nomOligo=".$nomOligo."&page=".$i."'>".$i.", </a>";
                } 
                break;
                
            case "sequence":
                for($i = 1; $i <= $nbPages; $i++){
                    var_dump($sequence);
                    echo "<a href='./?action=listeResultatOligo&critere=".$critere."&nsequence=".$sequence."&page=".$i."'>".$i.", </a>";
                }                 
        }
               
    }
    else{
?>
        <p>
            Aucune occurence trouvée...
        </p>
<?php
}
?>