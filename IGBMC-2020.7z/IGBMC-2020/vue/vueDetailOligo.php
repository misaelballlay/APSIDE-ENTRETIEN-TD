
<h1>Oligo : <?= $unOligo['name']; ?></h1>


<p id="principal">
    
<div class="container">
  <form action="action_page.php">
      
    
    
    <div class="row">
      <div class="col-25">
        <label for="lname">Sequence</label>
      </div>
      <div class="col-75">
          
<?php

    $segment = $unOligo['sequence5to3'];
    $segment = FormatSequence($segment); 

    
    if(isset($_GET['seq'])){

        
        $spd='<span style="background-color:#39ff14;">';
        $spf='</span>';

        $rech = $_GET['seq'];

        $segment = str_replace($rech,$spd.$rech.$spf,$segment);
    }
?>          
        <p id="texteSequence"><?= $segment ?></p>
      </div>
    </div>       
      
      
      <div class="row">
      <div class="col-25">
        <label for="lname">Box</label>
      </div>
      <div class="col-75">
        <p id="texteSequence"><?= $uneBoite['code'] ?></p>
      </div>
    </div>        

  </form>
</div>    
</p>