

        <p>
            <img src="images/IGBMC.png" alt="logo de l'institut" />  
        </p>        


