<?php
if ($_SERVER["SCRIPT_FILENAME"] == __FILE__) {
    $racine = "..";
}
include_once "$racine/modele/PDF.php";
include_once "$racine/modele/bd.box.inc.php";

toPdf();

?>

