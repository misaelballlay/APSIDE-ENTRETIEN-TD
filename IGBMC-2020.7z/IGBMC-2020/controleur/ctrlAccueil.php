<?php

//Détermination de la racine
if ( $_SERVER["SCRIPT_FILENAME"] == __FILE__ ){
    $racine="..";
}

// creation du menu burger
$menuBurger = array();
$menuBurger[] = Array("url"=>"#","label"=>"Oligos");
$menuBurger[] = Array("url"=>"./?action=rechercheOligo&critere=nom","label"=>"->Recherche par nom");
$menuBurger[] = Array("url"=>"./?action=rechercheOligo&critere=sequence","label"=>"->Recherche par sequence");
$menuBurger[] = Array("url"=>"#","label"=>"Box");
$menuBurger[] = Array("url"=>"./?action=rechercheBox&critere=code","label"=>"->Recherche par code");
$menuBurger[] = Array("url"=>"./?action=impressionPDF","label"=>"->Impression en PDF");


// Affichage des vues
$titre = "Accueil - Gestion des oligos";
include "$racine/vue/entete.html.php";
include "$racine/vue/vueAccueil.php";
include "$racine/vue/pied.html.php";

?>