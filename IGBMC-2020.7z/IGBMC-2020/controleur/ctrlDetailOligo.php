<?php

if ($_SERVER["SCRIPT_FILENAME"] == __FILE__) {
    $racine = "..";
}
include_once "$racine/modele/bd.oligo.inc.php";
include_once "$racine/modele/bd.box.inc.php";

// creation du menu burger
$menuBurger = array();
$menuBurger[] = Array("url"=>"#","label"=>"Oligos");
$menuBurger[] = Array("url"=>"./?action=rechercheOligo&critere=nom","label"=>"->Recherche par nom");
$menuBurger[] = Array("url"=>"./?action=rechercheOligo&critere=sequence","label"=>"->Recherche par sequence");
$menuBurger[] = Array("url"=>"#","label"=>"Box");
$menuBurger[] = Array("url"=>"./?action=rechercheBox&critere=code","label"=>"->Recherche par code");
$menuBurger[] = Array("url"=>"./?action=impressionPDF","label"=>"->Impression en PDF");


// recuperation des donnees GET, POST, et SESSION
$id = $_GET["id"];

// appel des fonctions permettant de recuperer les donnees utiles à l'affichage 
$unOligo = getOligoById($id);
$uneBoite = getBoxById($unOligo['idBox']);
//$unTypeObjet = getTypeObjetByCode($unObjet['codeType']);

// appel du script de vue qui permet de gerer l'affichage des donnees
$titre = "Detail d'un oligo";
include "$racine/vue/entete.html.php";
include "$racine/vue/vueDetailOligo.php";
include "$racine/vue/pied.html.php";
?>