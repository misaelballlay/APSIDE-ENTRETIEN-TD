<?php

//Détermination de la racine
if ( $_SERVER["SCRIPT_FILENAME"] == __FILE__ ){
    $racine="..";
}

//Inclut les modèles nécessaires
include_once "$racine/modele/bd.oligo.inc.php";
include_once "$racine/modele/bd.box.inc.php";

// creation du menu burger
$menuBurger = array();
$menuBurger[] = Array("url"=>"#","label"=>"Oligos");
$menuBurger[] = Array("url"=>"./?action=rechercheOligo&critere=nom","label"=>"->Recherche par nom");
$menuBurger[] = Array("url"=>"./?action=rechercheOligo&critere=sequence","label"=>"->Recherche par sequence");
$menuBurger[] = Array("url"=>"#","label"=>"Box");
$menuBurger[] = Array("url"=>"./?action=rechercheBox&critere=code","label"=>"->Recherche par code");
$menuBurger[] = Array("url"=>"./?action=impressionPDF","label"=>"->Impression en PDF");


// Récupération du critère de recherche en GET, par défaut par numero
$critere = "code";
if (isset($_GET["critere"])) {
    $critere = $_GET["critere"];
}

switch($critere){
    case 'code':
        //Récupération du critère de recherche à afficher en POST ou en GET        
        $codeBox="";
        if (isset($_REQUEST["codeBox"])){
            $codeBox = $_REQUEST["codeBox"];
        }        
        // On demande au modèle de récupérer les données nécessaires à l'affichage
        $lesBoites = getBoxesByCode($codeBox);
        break;
}


// appel du script de vue qui permet de gerer l'affichage des donnees
$titre = "Recherche d'une boite";

//Entete
include "$racine/vue/entete.html.php";

//Vue résultat

 // affichage des resultats de la recherche
include "$racine/vue/vueResultRechercheBox.php";


//Vue pied de page
include "$racine/vue/pied.html.php";


?>