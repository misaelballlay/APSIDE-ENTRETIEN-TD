<?php

//Fonction qui retourne le fichier à afficher
function controleurPrincipal($action){
 
    $lesActions = array();
    $lesActions["defaut"] = "ctrlAccueil.php";
    $lesActions["detailOligo"] = "ctrlDetailOligo.php";
    $lesActions["rechercheOligo"] = "ctrlRechercheOligo.php";
    $lesActions["listeResultatOligo"] = "ctrlListeResultatOligo.php";   
    $lesActions["detailBox"] = "ctrlDetailBox.php";
    $lesActions["rechercheBox"] = "ctrlRechercheBox.php";
    $lesActions["listeResultatBox"] = "ctrlListeResultatBox.php";       
    $lesActions["impressionPDF"] = "ctrlImpressionPDF.php";        
  

    $controleur = $lesActions["defaut"];
    
    //Permet de vérifier que l'action existe et renvoie le nom du contrôleur PHP    
    if (array_key_exists ( $action , $lesActions )){
        $controleur = $lesActions[$action];
    }
    
    return $controleur;
}

?>