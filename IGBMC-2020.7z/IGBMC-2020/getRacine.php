<?php
    //Affecte comme racine le dossier où se trouve index.php
    $racine = dirname(__FILE__);
?>
