<?php
    if ($_SERVER["SCRIPT_FILENAME"] == __FILE__) {
        $racine = "..";
    }
    
    require("$racine/tools/fpdf182/fpdf.php");
    
class PDF extends FPDF{
    // En-tête
    function Header(){
        // Logo
        $this->Image('images/IGBMCOligo.png',10,6,30);
        // Police Arial gras 15
        $this->SetFont('Arial','B',15);
        // Décalage à droite
        $this->Cell(60);
        // Titre
        $today = date("d/m/Y");  
        $this->Cell(90,10,'Contenu des boites au '.$today,1,0,'C');
  
        // Saut de ligne
        $this->Ln(20);
    }
    
    // Pied de page
    function Footer(){
        // Positionnement à 1,5 cm du bas
        $this->SetY(-15);
        // Police Arial italique 8
        $this->SetFont('Arial','I',10);
        // Numéro de page
        $this->Cell(0,25,'Page '.$this->PageNo().'/{nb}',0,0,'C');
    }
}