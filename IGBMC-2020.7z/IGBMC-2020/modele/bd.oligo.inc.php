<?php

include_once "bd.inc.php";

function getOligosByNom($nomOligo) {
    
    $resultat = array();

    try {
        $cnx = connexionPDO();
        $req = $cnx->prepare("select id, name from oligo where name like :nomOligo order by name");
        $req->bindValue(':nomOligo', '%'.$nomOligo.'%', PDO::PARAM_STR);

        $req->execute();
        
        while ($ligne = $req->fetch(PDO::FETCH_ASSOC)) {
            $resultat[] = $ligne;
        }        

    } catch (PDOException $e) {
        print "Erreur !: " . $e->getMessage();
        die();
    }
    return $resultat;
}

function getOligoById($id) {

    try {
        $cnx = connexionPDO();
        $req = $cnx->prepare("select * from oligo where id = :id");
        $req->bindValue(':id', $id, PDO::PARAM_STR);        
        $req->execute();

        $resultat=$req->fetch(PDO::FETCH_ASSOC);

    } catch (PDOException $e) {
        print "Erreur !: " . $e->getMessage();
        die();
    }
    return $resultat;
}

function getOligosBySequence($sequence) {
    
    $resultat = array();

    try {
        $cnx = connexionPDO();
        $req = $cnx->prepare("select id, name from oligo where sequence5to3 like :sequence order by name");
        $req->bindValue(':sequence', '%'.$sequence.'%', PDO::PARAM_STR);

        $req->execute();
        
        while ($ligne = $req->fetch(PDO::FETCH_ASSOC)) {
            $resultat[] = $ligne;
        }        

    } catch (PDOException $e) {
        print "Erreur !: " . $e->getMessage();
        die();
    }
    return $resultat;
}

function getOligosByBox($idBox) {
    
    $resultat = array();

    try {
        $cnx = connexionPDO();
        $req = $cnx->prepare("select id, name from oligo where idBox = :idBox order by name");
        $req->bindValue(':idBox', $idBox, PDO::PARAM_INT);

        $req->execute();
        
        while ($ligne = $req->fetch(PDO::FETCH_ASSOC)) {
            $resultat[] = $ligne;
        }        

    } catch (PDOException $e) {
        print "Erreur !: " . $e->getMessage();
        die();
    }
    return $resultat;
}

function FormatSequence($sequence){
    $res = "";
    for($i = 1 ; $i <= strlen($sequence); $i++){
        $res = $res.$sequence[$i - 1];
        if($i%3 == 0){
            $res = $res." ";
        }
    }
    return $res;
}



if ($_SERVER["SCRIPT_FILENAME"] == __FILE__) {
    // prog principal de test
    header('Content-Type:text/plain');

   }
?>