<?php

include_once "bd.inc.php";
include_once "PDF.php";
include_once "bd.oligo.inc.php";


function getBoxById($id) {

    try {
        $cnx = connexionPDO();
        $req = $cnx->prepare("select * from box where id = :id");
        $req->bindValue(':id', $id, PDO::PARAM_INT);        
        $req->execute();

        $resultat=$req->fetch(PDO::FETCH_ASSOC);

    } catch (PDOException $e) {
        print "Erreur !: " . $e->getMessage();
        die();
    }
    return $resultat;
}

function getBoxesByCode($codeBox) {
    $resultat = array();

    try {
        $cnx = connexionPDO();
        $req = $cnx->prepare("select * from box where code like :codeBox order by code");
        $req->bindValue(':codeBox', '%'.$codeBox.'%', PDO::PARAM_STR);

        $req->execute();

        while ($ligne = $req->fetch(PDO::FETCH_ASSOC)) {
            $resultat[] = $ligne;
        }        

    } catch (PDOException $e) {
        print "Erreur !: " . $e->getMessage();
        die();
    }
    return $resultat;
}

function readAll() {
    $resultat = array();

    try {
        $cnx = connexionPDO();
        $req = $cnx->prepare("select code, name, sequence5to3 from box join oligo on box.id = idBox order by code, name");

        $req->execute();

        while ($ligne = $req->fetch(PDO::FETCH_ASSOC)) {
            $resultat[] = $ligne;
        }        

    } catch (PDOException $e) {
        print "Erreur !: " . $e->getMessage();
        die();
    }
    return $resultat;
}

function toPdf(){
    $pdf = new PDF();
    $pdf->AliasNbPages();
    $pdf->AddPage();
    $pdf->SetFont('Times','B',10);
    
    $lesBoites = readAll();
    
    
    
    //mise en place de l'algorithme parcours séquentiel avec rupture
    $i = 0;
    while($i < count($lesBoites)){
        $pdf->SetFont('Times','B',10);        
        $boiteEnCours = $lesBoites[$i]['code'];
        $pdf->Cell(0,10,$boiteEnCours,1,1);        
        $pdf->Ln();
        
        
        //entête du tableau
        //
        // Largeurs des colonnes
        $pdf->Cell(35,7,"Nom oligo",1,0,'C');
        $pdf->Cell(155,7,utf8_decode("Séquence"),1,0,'C');        
        $pdf->Ln();
        
        $pdf->SetFont('Times','',10);
        while($i < count($lesBoites) && (strcmp($lesBoites[$i]['code'],$boiteEnCours) == 0)){
            if(strlen($lesBoites[$i]['sequence5to3']) > 53){
                $pdf->Cell(35,14,utf8_decode($lesBoites[$i]['name']),1,0,'C');
            }
            else{
                $pdf->Cell(35,7,utf8_decode($lesBoites[$i]['name']),1,0,'C');                
            }
            $sequenceFormate = FormatSequence($lesBoites[$i]['sequence5to3']);
            $pdf->MultiCell(155,7,$sequenceFormate,1,'L',false);            
            $i++;
        }
        $pdf->AddPage();
    }
   
    $pdf->Output();    
}



?>